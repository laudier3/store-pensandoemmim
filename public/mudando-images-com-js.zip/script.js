function over0() {
   document.getElementById("logo").src = './0-0.png';
}

function over1() {
    document.getElementById("logo").src = './0-1.png';
 }

 function over2() {
    document.getElementById("logo").src = './0-2.png';
 }

 function over3() {
    document.getElementById("logo").src = './0-3.png';
 }

function out(img) {
    document.getElementById("logo").src = './0-0.png';
 }
 